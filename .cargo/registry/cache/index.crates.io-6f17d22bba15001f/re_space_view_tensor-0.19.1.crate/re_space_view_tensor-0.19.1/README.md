# re_space_view_tensor

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_space_view_tensor.svg)](https://crates.io/crates/re_space_view_tensor)
[![Documentation](https://docs.rs/re_space_view_tensor/badge.svg)](https://docs.rs/re_space_view_tensor)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

A Space View dedicated to visualizing tensors with arbitrary dimensionality.


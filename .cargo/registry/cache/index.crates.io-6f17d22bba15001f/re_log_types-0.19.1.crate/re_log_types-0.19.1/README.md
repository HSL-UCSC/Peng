# re_log_types

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_log_types.svg)](https://crates.io/crates/re_log_types)
[![Documentation](https://docs.rs/re_log_types/badge.svg)](https://docs.rs/re_log_types)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

The basic building blocks of the Rerun data types and tables.

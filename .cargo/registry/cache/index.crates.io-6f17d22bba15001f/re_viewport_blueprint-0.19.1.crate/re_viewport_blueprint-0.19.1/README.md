# re_viewport_blueprint

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_viewport_blueprint.svg)](https://crates.io/crates/re_viewport_blueprint)
[![Documentation](https://docs.rs/re_viewport_blueprint/badge.svg)](https://docs.rs/re_viewport_blueprint)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

The data model describing the layout of the viewport.

class TestGlueInterface {
    static func testOpenBrowser(url: String) -> Void {
        test_open_webbrowser(url)
    }
}

# re_format

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_format.svg)](https://crates.io/crates/re_format)
[![Documentation](https://docs.rs/re_format/badge.svg)](https://docs.rs/re_format)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)


Miscellaneous tools to format and parse numbers, durations, etc.

pub type Digest = u64;

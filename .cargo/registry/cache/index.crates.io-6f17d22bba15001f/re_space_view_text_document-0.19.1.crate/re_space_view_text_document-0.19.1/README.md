# re_space_view_text_document

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_space_view_text_document.svg)](https://crates.io/crates/re_space_view_text_document)
[![Documentation](https://docs.rs/re_space_view_text_document/badge.svg)](https://docs.rs/re_space_view_text_document)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

A simple Space View that shows a single text box.

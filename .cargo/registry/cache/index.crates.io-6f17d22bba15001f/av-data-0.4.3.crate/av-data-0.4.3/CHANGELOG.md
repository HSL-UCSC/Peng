## Version 0.4.2

- Update num-derive from 0.3 to 0.4.

## Version 0.4.1

- Use initialized data for a frame.

## Version 0.4.0

- Upgrade to Rust edition 2021.
- Improve documentation.
- Pre-allocate planes.
- Update `num-rational` crate requirement.
- Update `bytes` crates.
- Refactor `Frame`.
- Add trait for copying to/from a buffer.
- Fix colorspace error.
- Fix an API misuse.

# re_smart_channel

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_smart_channel.svg)](https://crates.io/crates/re_smart_channel)
[![Documentation](https://docs.rs/re_smart_channel/badge.svg)](https://docs.rs/re_smart_channel)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

A channel for communicating between threads that keeps track of latency and queue length.

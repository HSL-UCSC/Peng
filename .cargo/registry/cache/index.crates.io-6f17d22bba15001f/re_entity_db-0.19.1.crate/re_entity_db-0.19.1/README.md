# re_entity_db

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_entity_db.svg)](https://crates.io/crates/re_entity_db)
[![Documentation](https://docs.rs/re_entity_db/badge.svg)](https://docs.rs/re_entity_db)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

In-memory storage of Rerun log data, indexed for fast queries.

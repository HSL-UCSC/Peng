# re_selection_panel

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_selection_panel.svg)](https://crates.io/crates/re_selection_panel)
[![Documentation](https://docs.rs/re_selection_panel/badge.svg)](https://docs.rs/re_selection_panel)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

The UI for the selection panel.

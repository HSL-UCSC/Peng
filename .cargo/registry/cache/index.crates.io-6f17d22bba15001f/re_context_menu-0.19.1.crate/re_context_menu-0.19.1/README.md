# re_context_menu

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_context_menu.svg)](https://crates.io/crates/re_context_menu)
[![Documentation](https://docs.rs/re_context_menu/badge.svg)](https://docs.rs/re_context_menu)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

Support crate for context menu and actions.

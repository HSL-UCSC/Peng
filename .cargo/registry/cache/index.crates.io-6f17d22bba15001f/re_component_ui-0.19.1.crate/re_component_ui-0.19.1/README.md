# re_component_ui

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_component_ui.svg)](https://crates.io/crates/re_component_ui)
[![Documentation](https://docs.rs/re_component_ui/badge.svg)](https://docs.rs/re_component_ui)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

Provides UI editors for Rerun component data for registration with the Rerun Viewer component UI registry.

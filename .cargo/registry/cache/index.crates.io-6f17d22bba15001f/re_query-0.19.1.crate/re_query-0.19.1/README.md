# re_query

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_query.svg)](https://crates.io/crates/re_query)
[![Documentation](https://docs.rs/re_query/badge.svg)](https://docs.rs/re_query)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

High-level query APIs.

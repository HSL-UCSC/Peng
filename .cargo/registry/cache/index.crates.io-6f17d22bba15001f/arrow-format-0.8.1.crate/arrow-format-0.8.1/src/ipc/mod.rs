mod generated;
pub use generated::org::apache::arrow::flatbuf::*;

/// Re-export of flatbuffers
pub use ::planus;

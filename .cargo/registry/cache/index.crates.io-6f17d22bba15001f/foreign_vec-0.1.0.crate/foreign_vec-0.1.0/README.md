# Foreign Vec

[![test](https://github.com/DataEngineeringLabs/foreign_vec/actions/workflows/miri.yaml/badge.svg)](https://github.com/DataEngineeringLabs/foreign_vec/actions/workflows/miri.yaml)
[![codecov](https://codecov.io/gh/DataEngineeringLabs/foreign_vec/branch/main/graph/badge.svg?token=AgyTF60R3D)](https://codecov.io/gh/DataEngineeringLabs/foreign_vec)
[![](https://img.shields.io/crates/d/foreign_vec.svg)](https://crates.io/crates/foreign_vec)
[![](https://img.shields.io/crates/dv/foreign_vec.svg)](https://crates.io/crates/foreign_vec)
[![](https://docs.rs/foreign_vec/badge.svg)](https://docs.rs/foreign_vec)

See [docs.md](./src/docs.md) for details.

## License

Licensed under either of

 * Apache License, Version 2.0 ([LICENSE-APACHE](LICENSE-APACHE) or http://www.apache.org/licenses/LICENSE-2.0)
 * MIT license ([LICENSE-MIT](LICENSE-MIT) or http://opensource.org/licenses/MIT)

at your option.

### Contribution

Unless you explicitly state otherwise, any contribution intentionally submitted for inclusion in the work by you, as defined in the Apache-2.0 license, shall be dual licensed as above, without any additional terms or conditions.

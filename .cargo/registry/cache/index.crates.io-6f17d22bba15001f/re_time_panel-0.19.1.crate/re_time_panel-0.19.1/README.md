# re_time_panel

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_data_ui.svg)](https://crates.io/crates/re_data_ui)
[![Documentation](https://docs.rs/re_data_ui/badge.svg)](https://docs.rs/re_data_ui)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

The time panel of the Rerun Viewer, allowing to control the displayed timeline & time.

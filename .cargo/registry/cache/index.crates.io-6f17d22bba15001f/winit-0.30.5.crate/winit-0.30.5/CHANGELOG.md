Changelog entries should be put in the [`changelog::unreleased`].

The changelog can also be viewed [on docs.rs][docs_rs] or [on the current
master docs][master_docs].

[`changelog::unreleased`]: src/changelog/unreleased.md
[docs_rs]: https://docs.rs/winit/latest/winit/changelog/index.html
[master_docs]: https://rust-windowing.github.io/winit/winit/changelog/index.html

# Code of Conduct

The `rust-windowing` project adheres to the [Rust Code of Conduct]. This
describes the minimum behavior expected from all contributors.

[Rust Code of Conduct]: https://www.rust-lang.org/policies/code-of-conduct
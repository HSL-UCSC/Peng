# re_space_view_dataframe

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_space_view_dataframe.svg)](https://crates.io/crates/re_space_view_dataframe)
[![Documentation](https://docs.rs/re_space_view_dataframe/badge.svg)](https://docs.rs/re_space_view_dataframe)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

A Space View that shows the data contained in entities in a table.

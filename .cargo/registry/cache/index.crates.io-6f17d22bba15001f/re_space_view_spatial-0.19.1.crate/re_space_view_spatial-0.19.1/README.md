# re_space_view_spatial

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_space_view_spatial.svg)](https://crates.io/crates/re_space_view_spatial)
[![Documentation](https://docs.rs/re_space_view_spatial/badge.svg)](https://docs.rs/re_space_view_spatial)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

Space Views that show entities in a 2D or 3D spatial relationship.

# re_space_view_bar_chart

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_space_view_bar_chart.svg)](https://crates.io/crates/re_space_view_bar_chart)
[![Documentation](https://docs.rs/re_space_view_bar_chart/badge.svg)](https://docs.rs/re_space_view_bar_chart)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

A Space View that shows plots over Rerun timelines.


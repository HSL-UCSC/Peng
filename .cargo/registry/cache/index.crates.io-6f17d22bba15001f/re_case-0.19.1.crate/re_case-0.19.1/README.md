# re_case

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_case.svg)](https://crates.io/crates/re_case)
[![Documentation](https://docs.rs/re_case/badge.svg)](https://docs.rs/re_case)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

Case conversions, the way Rerun likes them.

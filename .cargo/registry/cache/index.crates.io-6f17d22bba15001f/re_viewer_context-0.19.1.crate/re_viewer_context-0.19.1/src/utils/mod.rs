mod color;
mod text;

pub use color::{auto_color_egui, auto_color_for_entity_path};
pub use text::level_to_rich_text;

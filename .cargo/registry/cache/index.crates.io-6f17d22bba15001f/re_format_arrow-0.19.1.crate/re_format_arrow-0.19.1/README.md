# re_format_arrow

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_format_arrow.svg)](https://crates.io/crates/re_format_arrow)
[![Documentation](https://docs.rs/re_format_arrow/badge.svg)](https://docs.rs/re_format_arrow)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)


High-level formatting of Arrow tables.

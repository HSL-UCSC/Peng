use super::SpaceViewClass;

impl Default for SpaceViewClass {
    #[inline]
    fn default() -> Self {
        "Dataframe".into()
    }
}

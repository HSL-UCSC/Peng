use super::GammaCorrection;

impl Default for GammaCorrection {
    #[inline]
    fn default() -> Self {
        1.0.into()
    }
}

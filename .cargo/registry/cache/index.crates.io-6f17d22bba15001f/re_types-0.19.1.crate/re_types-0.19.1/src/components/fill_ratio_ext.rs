use super::FillRatio;

impl Default for FillRatio {
    #[inline]
    fn default() -> Self {
        1.0.into()
    }
}

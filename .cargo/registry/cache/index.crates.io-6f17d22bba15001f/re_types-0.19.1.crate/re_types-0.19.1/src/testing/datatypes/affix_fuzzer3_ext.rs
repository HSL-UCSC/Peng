impl Default for super::AffixFuzzer3 {
    #[inline]
    fn default() -> Self {
        Self::Degrees(0.0)
    }
}

impl Default for super::AffixFuzzer4 {
    #[inline]
    fn default() -> Self {
        Self::SingleRequired(Default::default())
    }
}

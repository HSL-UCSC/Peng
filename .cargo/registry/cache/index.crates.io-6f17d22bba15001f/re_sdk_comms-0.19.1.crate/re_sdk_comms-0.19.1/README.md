# re_sdk_comms

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_sdk_comms.svg)](https://crates.io/crates/store/re_sdk_comms)
[![Documentation](https://docs.rs/re_sdk_comms/badge.svg)](https://docs.rs/re_sdk_comms)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

TCP communication between Rerun SDK and Rerun Server.

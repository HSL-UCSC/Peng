# re_blueprint_tree

Part of the [`rerun`](https://github.com/rerun-io/rerun) family of crates.

[![Latest version](https://img.shields.io/crates/v/re_blueprint_tree.svg)](https://crates.io/crates/re_blueprint_tree)
[![Documentation](https://docs.rs/re_blueprint_tree/badge.svg)](https://docs.rs/re_blueprint_tree)
![MIT](https://img.shields.io/badge/license-MIT-blue.svg)
![Apache](https://img.shields.io/badge/license-Apache-blue.svg)

The UI for the blueprint tree in the left panel.

//! This crate implements the UI for the blueprint tree in the left panel.

mod blueprint_tree;

pub use blueprint_tree::BlueprintTree;

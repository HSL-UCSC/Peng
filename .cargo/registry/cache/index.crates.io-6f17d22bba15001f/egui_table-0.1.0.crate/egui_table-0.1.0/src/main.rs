//! Example of a Rust binary.

fn main() {
    println!("Hello, egui_table!");
}

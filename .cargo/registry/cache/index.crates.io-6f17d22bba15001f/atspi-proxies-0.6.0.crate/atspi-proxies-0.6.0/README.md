# `atspi-proxies`

An internal crate used by other `atspi-*` crates.
This handles direct communication with DBus.

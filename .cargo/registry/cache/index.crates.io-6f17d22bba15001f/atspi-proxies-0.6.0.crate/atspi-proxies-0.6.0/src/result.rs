pub type AtspiResult<T> = Result<T, crate::AtspiError>;

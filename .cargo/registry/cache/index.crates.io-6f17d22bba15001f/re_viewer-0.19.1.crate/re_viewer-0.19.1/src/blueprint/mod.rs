pub mod validation;

mod validation_gen;

pub use validation_gen::is_valid_blueprint;

/// Enable allocation tracking (very slow - use it to find memory leaks!).
///
/// `RERUN_TRACK_ALLOCATIONS=1`
pub const RERUN_TRACK_ALLOCATIONS: &str = "RERUN_TRACK_ALLOCATIONS";
